package com.tothenew;

import junit.framework.TestCase;
import org.junit.Test;

public class TestMavenDemo {

    @Test
    public void testDisp() {
        System.out.println("Hello Varsha!!!!");
    }
}